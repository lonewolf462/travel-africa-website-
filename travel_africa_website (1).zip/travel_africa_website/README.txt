TRAVEL AFRICA WEBSITE — QUICK START

FILES
- index.html: the complete responsive website. Open it in a browser to preview.

BEFORE PUBLISHING
1. Open index.html in a text editor.
2. Find YOUR_EMAIL_HERE and replace it with the business email address you want customers to use.
   Example: hello@yourdomain.com
3. Save the file.
4. Open index.html in a browser to preview it.

PUBLISH FREE WITH GITHUB PAGES
1. Create or sign in to a GitHub account at https://github.com/
2. Create a new public repository. A name like travel-africa-website works.
3. Upload index.html (and this README if you wish) to the repository root.
4. In the repository, open Settings → Pages.
5. Under Build and deployment, choose Deploy from a branch.
6. Select the main branch and /(root), then Save.
7. Wait a few minutes. The Pages section will show your published website address.

NOTES
- The website uses externally hosted Unsplash images, so an internet connection is required for the photos.
- The email button opens the visitor's email app; it does not submit a form or store enquiries.
- This starter website contains general travel copy. Update business details, policies, services and any claims so they accurately reflect your business.
- GitHub Pages provides free static hosting. A custom domain is optional and usually costs money.
